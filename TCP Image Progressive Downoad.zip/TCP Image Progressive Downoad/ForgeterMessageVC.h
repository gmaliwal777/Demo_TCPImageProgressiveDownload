//
//  ForgeterMessageVC.h
//  Forgeter
//
//  Created by Ravi Tailor on 08/01/15.
//  Copyright (c) 2015 Ravi Taylor. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AlertView.h"

@interface ForgeterMessageVC : UIViewController{
    dispatch_once_t     onceBlockExecution;
    AlertView           *alert;
}

/**
 *this property holds detail of recepient
 */
@property (nonatomic,strong)      NSDictionary *dictUserDetail;

/**
  *this property used to say that some another controll is presented or not
  */
@property (nonatomic,assign)     BOOL          someControllerPresented;

@end
