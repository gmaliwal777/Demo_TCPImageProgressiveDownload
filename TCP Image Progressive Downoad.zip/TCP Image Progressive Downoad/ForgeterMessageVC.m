//
//  ForgeterMessageVC.m
//  Forgeter
//
//  Created by Ravi Tailor on 08/01/15.
//  Copyright (c) 2015 Ravi Taylor. All rights reserved.
//

#import "ForgeterMessageVC.h"
#import "TextChatCell.h"
#import "ChatMediaCell.h"
#import "LocationChatCell.h"
#import "ContactChatCell.h"
#import "AudioChatCell.h"
#import "GetForgeterMsgWS.h"
#import "UIImageView+WebCache.h"
#import "PersonInfo.h"
#import "MHGalleryItem.h"
#import "MHGalleryController.h"
#import "UIImage+FixOrientation.h"
#import "InvitiDetailVC.h"
#import "ShareLocationVC.h"


#define FORGETTER_MESSAGE @"This message will be sent on "

@interface ForgeterMessageVC ()<UITableViewDataSource,UITableViewDelegate,GetForgeterMsgWSDelegate>
@property (strong, nonatomic) IBOutlet UITableView *tblForgeter;
@property (strong, nonatomic) GetForgeterMsgWS *objForgeterMsgList;
@property (strong, nonatomic) NSMutableArray *arrFortMsg;
@end

@implementation ForgeterMessageVC
@synthesize dictUserDetail,arrFortMsg;

#pragma mark--
#pragma mark-- UIViewController LifeCycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tblForgeter setHidden:YES];
    // Do any additional setup after loading the view.
    
    //Default Configuration
    _someControllerPresented = NO;
}

-(void)dealloc{
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    dispatch_once(&onceBlockExecution, ^{
        //Setup Navigation bar
        [self setupNavigationBar];
        
        //TCP Communication channel setup
        _objForgeterMsgList = [[GetForgeterMsgWS alloc] init];
        _objForgeterMsgList.delegate = self;
    });
    
    if (!_someControllerPresented) {
        [self callForgeterDetail];
    }
    _someControllerPresented = NO;
}


#pragma mark--
#pragma mark-- Custom Methods
/**
 *Selector used to download video
 *
 */
-(void)callVideoDownload:(UIButton *)btnDownLoad{
    //Removing callVideoDownload , so further this action can not be called by user
    [btnDownLoad removeTarget:self action:@selector(callVideoDownload:) forControlEvents:UIControlEventTouchUpInside];
    
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:btnDownLoad.tag inSection:0];
    UITableViewCell *cell = [_tblForgeter cellForRowAtIndexPath:indexPath];
    
    if (cell && [cell isKindOfClass:[ChatMediaCell class]]) {
        NSDictionary *msgDict = [arrFortMsg objectAtIndex:btnDownLoad.tag];
        NSString *mediaURL = [msgDict objectForKey:@"turl"];
        NSLog(@"local media url is %@",[CommonFuntions localMediaPathForServerFile:mediaURL]);
        ChatMediaCell *chatCell = (ChatMediaCell *)cell;
        [chatCell.btnDownload addTarget:nil action:NULL forControlEvents:UIControlEventTouchUpInside];
        [[NSNotificationCenter defaultCenter] removeObserver:cell];
        if (chatCell.mediaQuickDonwloader) {
            @try{
                [chatCell.mediaQuickDonwloader removeObserver:chatCell forKeyPath:@"loadedFile"];
            }@catch(id anException){}
        }
        
        MediaQuickDownload *mediaDownloader = [[MediaQuickDownload alloc] init];
        mediaDownloader.mediaType = Video;
        mediaDownloader.imgMedia = chatCell.imgChatMedia;
        chatCell.controller = self;
        chatCell.mediaQuickDonwloader = mediaDownloader;
        [mediaDownloader addObserver:chatCell forKeyPath:@"loadedFile" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:nil];
        [mediaDownloader downloadForgeterMedia:mediaURL];
        [chatCell.mediaIndicator startAnimating];
    }
}

/**
 *Used to show activity indicator when message is forgeter
 *
 */
-(void)stopDownloadingContent{
    //Displaying cell downloding stop
    UITableView *tableView = self.tblForgeter;
    NSInteger sections = tableView.numberOfSections;
    for (int section = 0; section < sections; section++) {
        NSInteger rows =  [tableView numberOfRowsInSection:section];
        for (int row = 0; row < rows; row++) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:section];
            UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
            //**here, for those cells not in current screen, cell is nil**
            if (cell && [cell isKindOfClass:[ChatMediaCell class]]) {
                //Stop Image/Video Downloading
                ChatMediaCell *chatCell = (ChatMediaCell *)cell;
                if (chatCell.mediaQuickDonwloader) {
                    NSLog(@"stoping media downloading");
                    [chatCell.mediaQuickDonwloader stopDownloading];
                }
            }
        }
    }
    
    
    //Dequesd ChatMediaCell Downloading stop
    ChatMediaCell *cell= (ChatMediaCell *)[tableView dequeueReusableCellWithIdentifier:@"ChatMediaCell"];
    while (cell && [cell isKindOfClass:[ChatMediaCell class]]) {
        //Stop Image/Video Downloading
        ChatMediaCell *chatCell = (ChatMediaCell *)cell;
        if (chatCell.mediaQuickDonwloader) {
            NSLog(@"stoping media downloading in dequed cell");
            [chatCell.mediaQuickDonwloader stopDownloading];
        }
        cell= (ChatMediaCell *)[tableView dequeueReusableCellWithIdentifier:@"ChatMediaCell"];
    }
}

/**
 *Used to show Media in full representation
 *
 */
-(void)showChatMediaOnClick:(UIButton *)btnMedia
{
    
    BOOL fileIsDownloading = NO;
    // Chat Dictionary
    ChatMediaCell   *mediaCell = (ChatMediaCell *)[[btnMedia superview] superview];
    if ([mediaCell isKindOfClass:[ChatMediaCell class]] &&
        [mediaCell.indicator isAnimating]) {
        // Media is being downloaded
        fileIsDownloading = YES;
    }else{
        NSDictionary *msgDict=[arrFortMsg objectAtIndex:btnMedia.tag];
        
        NSString *mediaURL = [msgDict objectForKey:@"turl"];
        NSString *mediaName = [[mediaURL componentsSeparatedByString:@"/"] lastObject];
        NSArray *arrPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
        NSString *cachePath = [arrPaths objectAtIndex:0];
        NSString *localMediaPath = [cachePath stringByAppendingPathComponent:mediaName];
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        
        if(mediaURL && [fileManager fileExistsAtPath:localMediaPath]){
            //file is existing locally can be viewed on full screen
            
            [[UINavigationBar appearance] setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
            MHGalleryController *gallery = [MHGalleryController galleryWithPresentationStyle:MHGalleryViewModeImageViewerNavigationBarShown];
            NSMutableArray *galleryArray = [[NSMutableArray alloc] init];
            
            MHGalleryItem *galleryItem = [[MHGalleryItem alloc] init];
            if([[msgDict objectForKey:@"ftype"] isEqualToString:@"image"])
            {
                [galleryItem setGalleryType:MHGalleryTypeImage];
            }else if ([[msgDict objectForKey:@"ftype"] isEqualToString:@"video"]){
                [galleryItem setGalleryType:MHGalleryTypeVideo];
            }
            [galleryItem setURLString:[[NSURL fileURLWithPath:localMediaPath] absoluteString]];
            [galleryArray addObject:galleryItem];
            
            gallery.galleryItems = [NSArray arrayWithArray:(NSArray *)galleryArray];
            //        gallery.presentationIndex = anIndex;
            gallery.UICustomization.showMHShareViewInsteadOfActivityViewController = NO;
            gallery.transitionCustomization.interactiveDismiss = NO;
            gallery.transitionCustomization.dismissWithScrollGestureOnFirstAndLastImage = NO;
            gallery.UICustomization.showOverView = NO;
            __weak MHGalleryController *blockGallery = gallery;
            
            gallery.finishedCallback = ^(NSUInteger currentIndex,UIImage *image,MHTransitionDismissMHGallery *interactiveTransition,MHGalleryViewMode viewMode){
                [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"NavigationBarBg"] forBarMetrics:UIBarMetricsDefault];
                
                [blockGallery dismissViewControllerAnimated:YES completion:^{
                    [self setNeedsStatusBarAppearanceUpdate];
                }];
                
            };
            [self presentMHGalleryController:gallery animated:YES completion:^{
                _someControllerPresented = YES;
            }];
            
        }else{
            fileIsDownloading = YES;
        }
    }
    
    if (fileIsDownloading) {
        //file is not existing locally , please let it update
        NSMutableArray *arrActions = [[NSMutableArray alloc] init];
        
        //Ok Button
        NSDictionary *dictTab = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
            
        },@"action", nil];
        [arrActions addObject:dictTab];
        
        alert = [[AlertView alloc] init];
        UIViewController *currentVC = self;
        [alert showAlertView:@"please let file to download" arrActions:arrActions onHandler:currentVC];
    }
    
}

/**
 *Used to show location on map
 *
 */
-(void)showLocationInMap:(UIButton*)btn
{
    NSDictionary *msgDict=[arrFortMsg objectAtIndex:btn.tag];
    NSLog(@"msg dict for location is %@",msgDict);
    ShareLocationVC *shareLV = [[ShareLocationVC alloc]initWithNibName:@"ShareLocationVC" bundle:nil];
    shareLV.viewType=@"showlocation";
    NSArray *arrLoc = [[msgDict objectForKey:@"turl"] componentsSeparatedByString:@"#"];
    shareLV.dictLocationInfo =[[NSDictionary alloc] initWithObjectsAndKeys:[arrLoc objectAtIndex:0],@"lat",[arrLoc objectAtIndex:1],@"long",[arrLoc objectAtIndex:2],@"address", nil];
    [self.navigationController pushViewController:shareLV animated:YES];
}

/**
  *Used to call contact detail
  *
  */
-(void)showContactDetail:(UIButton *)btn
{
    NSDictionary *msgDict=[arrFortMsg objectAtIndex:btn.tag];
    NSLog(@"msg dict for location is %@",msgDict);
    if([self isNotNull:[msgDict objectForKey:@"turl"]])
    {
        Person *objPersons = [[Person alloc] init];
        NSString *strMessage = [msgDict objectForKey:@"turl"];
        NSArray *arrLocation= [strMessage componentsSeparatedByString:@"#"];
        if(arrLocation.count>0)
        {
            for(int i=0; i<arrLocation.count; i++)
            {
                switch (i) {
                    case 0:
                        if([self isNotNull:[arrLocation objectAtIndex:0]])
                        {
                            objPersons.address = [arrLocation objectAtIndex:0];
                        }
                        break;
                        
                    case 1:
                        if([self isNotNull:[arrLocation objectAtIndex:1]])
                        {
                            objPersons.city = [arrLocation objectAtIndex:1];
                        }
                        break;
                    case 2:
                        if([self isNotNull:[arrLocation objectAtIndex:2]])
                        {
                            objPersons.firstName = [arrLocation objectAtIndex:2];
                        }
                        break;
                    case 3:
                        if([self isNotNull:[arrLocation objectAtIndex:3]])
                        {
                            objPersons.homeEmail = [arrLocation objectAtIndex:3];
                        }
                        break;
                    case 4:
                        if([self isNotNull:[arrLocation objectAtIndex:4]])
                        {
                            objPersons.homeNumber = [arrLocation objectAtIndex:4];
                        }
                        break;
                    case 5:
                        if([self isNotNull:[arrLocation objectAtIndex:5]])
                        {
                            objPersons.lastName = [arrLocation objectAtIndex:5];
                        }
                        break;
                    case 6:
                        if([self isNotNull:[arrLocation objectAtIndex:6]])
                        {
                            objPersons.phoneNumber = [arrLocation objectAtIndex:6];
                        }
                        break;
                    case 7:
                        if([self isNotNull:[arrLocation objectAtIndex:7]])
                        {
                            objPersons.workEmail = [arrLocation objectAtIndex:7];
                        }
                        
                        break;
                    case 8:
                        if([self isNotNull:[arrLocation objectAtIndex:8]])
                        {
                            objPersons.zipCode = [arrLocation objectAtIndex:8];
                        }
                        break;
                }
            }
            InvitiDetailVC *objInvite = [[InvitiDetailVC alloc] initWithNibName:@"InvitiDetailVC" bundle:nil];
            objInvite.person = objPersons;
            objInvite.isFromChat = true;
            objInvite.hidesBottomBarWhenPushed = YES;
            objInvite.typeChat = [msgDict objectForKey:@"typeChat"];
            objInvite.countryCode = [NSString stringWithFormat:@"%@",[msgDict objectForKey:@"country_code"]];

            [self.navigationController pushViewController:objInvite animated:YES];
        }
    }
}

/**
 *Used to get video thumbnail
 *
 */
-(void)generateThumbnailIconForVideoFileWith:(NSURL *)contentURL WithSize:(CGSize)size thumbnailContainer:(UIImageView *)thumbnailContainer
{
    AVURLAsset *asset = [[AVURLAsset alloc] initWithURL:contentURL options:nil];
    AVAssetImageGenerator *generateImg = [[AVAssetImageGenerator alloc] initWithAsset:asset];
    generateImg.appliesPreferredTrackTransform = TRUE;
    NSError *error = NULL;
    CMTime time = CMTimeMake(1, 65);
    CGImageRef refImg = [generateImg copyCGImageAtTime:time actualTime:NULL error:&error];
    NSLog(@"error==%@, Refimage==%@", error, refImg);
    
    UIImage *FrameImage= [[UIImage alloc] initWithCGImage:refImg];
    [thumbnailContainer.layer setMasksToBounds:YES];
    FrameImage = FrameImage.fixOrientation;
    thumbnailContainer.image = FrameImage;
}

/**
 *Used to convert UTC date & time into local
 *
 */
-(NSString *)convertUTCtoLocal:(NSString *)utcdate
{
    NSString *dateStr = utcdate;
    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
    [dateFormatter1 setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *date = [dateFormatter1 dateFromString:dateStr];
    NSLog(@"date : %@",date);
    
    NSTimeZone *currentTimeZone = [NSTimeZone localTimeZone];
    NSTimeZone *utcTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    
    NSInteger currentGMTOffset = [currentTimeZone secondsFromGMTForDate:date];
    NSInteger gmtOffset = [utcTimeZone secondsFromGMTForDate:date];
    NSTimeInterval gmtInterval = currentGMTOffset - gmtOffset;
    
    NSDate *destinationDate = [[NSDate alloc] initWithTimeInterval:gmtInterval sinceDate:date];
    
    NSDateFormatter *dateFormatters = [[NSDateFormatter alloc] init];
    [dateFormatters setDateFormat:@"dd-MM-yyyy hh:mm a"];
    [dateFormatters setDateStyle:NSDateFormatterShortStyle];
    [dateFormatters setTimeStyle:NSDateFormatterShortStyle];
    [dateFormatters setDoesRelativeDateFormatting:YES];
    [dateFormatters setTimeZone:[NSTimeZone systemTimeZone]];
    dateStr = [dateFormatters stringFromDate: destinationDate];
    NSLog(@"DateString : %@", dateStr);
    return dateStr;
}

/**
  *Used to get row number in tableview
  *
  */
-(int)getRowNumber:(NSIndexPath *)indexPath{
    int rowNum = 0;
    
    for (int counter = 0;counter<indexPath.section;counter++) {
        NSInteger numberOfRowInSection = [_tblForgeter numberOfRowsInSection:counter];
        rowNum = rowNum+(int)numberOfRowInSection;
    }
    return rowNum+(int)indexPath.row;
}

/**
  *
  *Used to get back from current context
  */
-(void)goBack
{
    //Stop dataDownLoading
    [self stopDownloadingContent];
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)callForgeterDetail{
    [CommonFuntions showActivityIndicatorWithText:@"back"];
    if ([dictUserDetail objectForKey:@"type"]
        && [[dictUserDetail objectForKey:@"type"] isEqualToString:@"groupchat"]) {
        [_objForgeterMsgList getForgeterMsgListReceiverId:[dictUserDetail objectForKey:@"room_name"]];
    }else{
        [_objForgeterMsgList getForgeterMsgListReceiverId:[dictUserDetail objectForKey:@"openfire_username"]];
    }
}

#pragma mark--
#pragma mark-- set up navigation bar
-(void)setupNavigationBar
{
    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.backBarButtonItem = nil;
    
    
    //------------set Name on NavigationBar
    float width = [UIScreen mainScreen].bounds.size.width;
    CGSize textSize;
    
    
    if (self.navigationItem.leftBarButtonItem.customView && self.navigationItem.rightBarButtonItem.customView)
    {
        width = width - (self.navigationItem.leftBarButtonItem.customView.frame.size.width+self.navigationItem.rightBarButtonItem.customView.frame.size.width);
    }
    else if (self.navigationItem.leftBarButtonItem.customView && !self.navigationItem.rightBarButtonItem.customView)
    {
        width = width - (self.navigationItem.leftBarButtonItem.customView.frame.size.width*2);
    }
    else if (!self.navigationItem.leftBarButtonItem.customView && !self.navigationItem.rightBarButtonItem.customView)
    {
        width = width - (2*self.navigationItem.rightBarButtonItem.customView.frame.size.width);
    }
    
    
    CGRect frame;
    
    NSDictionary *attributesDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                          [UIFont fontWithName:@"Gentona-Bold" size:15.0f], NSFontAttributeName,
                                          nil];
    NSString *firstName = [dictUserDetail objectForKey:@"localFirstName"];
    NSString *lastName = [dictUserDetail objectForKey:@"localLastName"];
    
    NSString *header = @"";
    if (firstName.length!=0 || lastName.length!=0) {
        NSString *chatUserName = [firstName stringByAppendingString:@" "];
        header = [chatUserName stringByAppendingString:lastName];
    }else{
        header = ([dictUserDetail objectForKey:@"username"]?[dictUserDetail objectForKey:@"username"]:@"");
    }
    
    
    frame = [header boundingRectWithSize:CGSizeMake(width, FLT_MAX)
                                       options:NSStringDrawingUsesLineFragmentOrigin
                                    attributes:attributesDictionary
                                       context:nil];
    textSize=frame.size;
    
    
    
    if (textSize.width < width)
        width = textSize.width+75;
    
    UIView *view = [[UIView alloc]  initWithFrame:CGRectMake(0.0f, 0.0f, width, 44.0f)];
    view.tag = 900;
    view.userInteractionEnabled = YES;
  
    UILabel *titleLbl = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 5.0f, width,25.0f)];
    [titleLbl setFont:[UIFont fontWithName:@"Gentona-Bold" size:15.0f]];
    
    [titleLbl setBackgroundColor:[UIColor clearColor]];
    [titleLbl setTextAlignment:NSTextAlignmentCenter];
    
    [titleLbl setTextColor:[UIColor whiteColor]];
    
    [titleLbl setText:header];
    
    [view addSubview:titleLbl];
    

    
    [self.navigationItem setTitleView:view];
    
    
    [self.navigationItem setLeftBarButtonItem:nil animated:NO];
    UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 33)];
    [leftView setBackgroundColor:[UIColor colorWithRed:49.0/255.0f green:56.0f/255.0f blue:97.0f/255.0f alpha:1.0f]];
    leftView.bounds = CGRectOffset(leftView.bounds, 0, -2);
    
    UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(0.f, 0.f, 30.f, 30.f)];
    [backBtn setBackgroundColor:[UIColor clearColor]];
    [backBtn setImage:[UIImage imageNamed:@"backarrow"] forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    [leftView addSubview:backBtn];
    UIBarButtonItem *leftBarBtn = [[UIBarButtonItem alloc] initWithCustomView:leftView];
    
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                                                                        target:nil action:nil];
    leftNegativeSpacer.width = -15;
    
    
    [self.navigationItem setLeftBarButtonItems:[NSArray arrayWithObjects:leftNegativeSpacer,leftBarBtn,nil]];
    
   
    
    
    UIImageView *profileImgView = [[UIImageView alloc] initWithFrame:CGRectMake(9, 7, 30.0f, 30.0f)];
    profileImgView.backgroundColor = [UIColor clearColor];
    profileImgView.layer.cornerRadius= 15.0f;
    profileImgView.layer.masksToBounds=YES;
  
    [profileImgView sd_setImageWithURL:[NSURL URLWithString:[[dictUserDetail objectForKey:@"user_image"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:nil options:SDWebImageCacheMemoryOnly];
    
    profileImgView.userInteractionEnabled = YES;
   
    UIView *profileView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
    // profileView.bounds = CGRectOffset(profileView.bounds, -20, -2);
    //[profileView setBackgroundColor:[UIColor redColor]];
    profileView.userInteractionEnabled = YES;
   
    [profileView addSubview:profileImgView];
    
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithCustomView:profileView];
    
    UIBarButtonItem *rightNegativeSpacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                                                                         target:nil action:nil];
    rightNegativeSpacer.width = -15;
    
    [self.navigationItem setRightBarButtonItems:[NSArray arrayWithObjects:rightNegativeSpacer,rightBarButton,nil]];
    
    
    //----------hide tapbar ...----------
    [CommonFuntions hideTapBarWithIndex];
}

#pragma mark--
#pragma mark-- CHat Cell Custom Methods
/**
 *called to set Location Chat cell profile pic or initials
 *
 */

-(void)setLocationChatProfile:(LocationChatCell *)cell dictChat:(NSDictionary *)dictChat{
    if ([self isNotNull:[dictChat objectForKey:@"profile_image"]] &&
        [[[[dictChat objectForKey:@"profile_image"] componentsSeparatedByString:@"/"] lastObject] componentsSeparatedByString:@"."].count>1) {
        
        [cell.lblProfile setHidden:TRUE];
        [cell.imgProfile setHidden:NO];
        NSString *thumbnailURL = [dictChat objectForKey:@"profile_image"];
        NSString *thumbnailName = [[thumbnailURL componentsSeparatedByString:@"/"] lastObject];
        NSArray *arrPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
        NSString *cachePath = [arrPaths objectAtIndex:0];
        NSString *localThumbnailPath = [cachePath stringByAppendingPathComponent:thumbnailName];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if(thumbnailURL && [fileManager fileExistsAtPath:localThumbnailPath]){
            cell.imgProfile.image = [UIImage imageWithData:[NSData dataWithContentsOfFile:localThumbnailPath]];
            [cell.indicator stopAnimating];
        }else if(thumbnailURL){
            AsynImageDownLoad *asynImageDownLoad = [[AsynImageDownLoad alloc] init];
            cell.asyncDownload = asynImageDownLoad;
            [asynImageDownLoad downLoadingAsynImage:cell.imgProfile imagePath:thumbnailURL backgroundQueue:NULL];
        }else{
            [cell.indicator stopAnimating];
        }
        
    }else{
        [cell.indicator stopAnimating];
        [cell.lblProfile setHidden:NO];
        NSString *firstInitial = @"";
        NSString *lastInitial = @"";
        NSString *companyInitial = @"";
        
        if (((NSString *)[dictChat objectForKey:@"first_name"]).length!=0) {
            firstInitial = [[((NSString *)[dictChat objectForKey:@"first_name"]) substringToIndex:1] uppercaseString];
        }
        
        if (((NSString *)[dictChat objectForKey:@"last_name"]).length!=0) {
            lastInitial = [[((NSString *)[dictChat objectForKey:@"last_name"]) substringToIndex:1] uppercaseString];
        }
        
        if (((NSString *)[dictChat objectForKey:@"comapny"]).length!=0) {
            companyInitial = [[((NSString *)[dictChat objectForKey:@"company"]) substringToIndex:1] uppercaseString];
        }
        
        NSLog(@"company name is %@",companyInitial);
        [cell.imgProfile setImage:[UIImage imageNamed:@"companyIcon"]];
        [cell.imgProfile setHidden:NO];
        [cell.lblProfile setHidden:YES];
        
        if (firstInitial.length !=0 || lastInitial.length != 0) {
            [cell.lblProfile setText:[[NSString stringWithFormat:@"%@%@",firstInitial,lastInitial] uppercaseString]];
            cell.imgProfile.backgroundColor = UIColorFromRedGreenBlue(216, 218, 227);
            [cell.imgProfile setHidden:YES];
            [cell.lblProfile setHidden:NO];
        }else if (companyInitial.length != 0){
            //[cell.lblProfile setText:[[NSString stringWithFormat:@"%@",companyInitial] uppercaseString]];
            [cell.imgProfile setImage:[UIImage imageNamed:@"companyIcon"]];
            cell.imgProfile.backgroundColor = UIColorFromRedGreenBlue(216, 218, 227);
            [cell.imgProfile setHidden:NO];
            [cell.lblProfile setHidden:YES];
        }else{
            [cell.imgProfile setImage:[UIImage imageNamed:@"profile_icon"]];
            [cell.imgProfile setHidden:NO];
            [cell.lblProfile setHidden:YES];
        }
    }
}

/**
 *called to set Contact Chat cell profile pic or initials
 *
 */

-(void)setContactChatProfile:(ContactChatCell *)cell dictChat:(NSDictionary *)dictChat{
    if ([self isNotNull:[dictChat objectForKey:@"profile_image"]] &&
        [[[[dictChat objectForKey:@"profile_image"] componentsSeparatedByString:@"/"] lastObject] componentsSeparatedByString:@"."].count>1) {
        
        [cell.lblProfile setHidden:TRUE];
        [cell.imgProfile setHidden:NO];
        NSString *thumbnailURL = [dictChat objectForKey:@"profile_image"];
        NSString *thumbnailName = [[thumbnailURL componentsSeparatedByString:@"/"] lastObject];
        NSArray *arrPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
        NSString *cachePath = [arrPaths objectAtIndex:0];
        NSString *localThumbnailPath = [cachePath stringByAppendingPathComponent:thumbnailName];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if(thumbnailURL && [fileManager fileExistsAtPath:localThumbnailPath]){
            cell.imgProfile.image = [UIImage imageWithData:[NSData dataWithContentsOfFile:localThumbnailPath]];
            [cell.indicator stopAnimating];
        }else if(thumbnailURL){
            AsynImageDownLoad *asynImageDownLoad = [[AsynImageDownLoad alloc] init];
            cell.asyncDownload = asynImageDownLoad;
            [asynImageDownLoad downLoadingAsynImage:cell.imgProfile imagePath:thumbnailURL backgroundQueue:NULL];
        }else{
            [cell.indicator stopAnimating];
        }
        
    }else{
        [cell.indicator stopAnimating];
        [cell.lblProfile setHidden:NO];
        NSString *firstInitial = @"";
        NSString *lastInitial = @"";
        NSString *companyInitial = @"";
        
        if (((NSString *)[dictChat objectForKey:@"first_name"]).length!=0) {
            firstInitial = [[((NSString *)[dictChat objectForKey:@"first_name"]) substringToIndex:1] uppercaseString];
        }
        
        if (((NSString *)[dictChat objectForKey:@"last_name"]).length!=0) {
            lastInitial = [[((NSString *)[dictChat objectForKey:@"last_name"]) substringToIndex:1] uppercaseString];
        }
        
        if (((NSString *)[dictChat objectForKey:@"company"]).length!=0) {
            companyInitial = [[((NSString *)[dictChat objectForKey:@"company"]) substringToIndex:1] uppercaseString];
        }
        
        NSLog(@"company name is %@",companyInitial);
        [cell.imgProfile setImage:[UIImage imageNamed:@"companyIcon"]];
        [cell.imgProfile setHidden:NO];
        [cell.lblProfile setHidden:YES];
        
        if (firstInitial.length !=0 || lastInitial.length != 0) {
            [cell.lblProfile setText:[[NSString stringWithFormat:@"%@%@",firstInitial,lastInitial] uppercaseString]];
            cell.imgProfile.backgroundColor = UIColorFromRedGreenBlue(216, 218, 227);
            [cell.imgProfile setHidden:YES];
            [cell.lblProfile setHidden:NO];
        }else if (companyInitial.length != 0){
            //[cell.lblProfile setText:[[NSString stringWithFormat:@"%@",companyInitial] uppercaseString]];
            [cell.imgProfile setImage:[UIImage imageNamed:@"companyIcon"]];
            cell.imgProfile.backgroundColor = UIColorFromRedGreenBlue(216, 218, 227);
            [cell.imgProfile setHidden:NO];
            [cell.lblProfile setHidden:YES];
        }else{
            [cell.imgProfile setImage:[UIImage imageNamed:@"profile_icon"]];
            [cell.imgProfile setHidden:NO];
            [cell.lblProfile setHidden:YES];
        }
    }
}

/**
 *called to set Audio Media cell profile pic or initials
 *
 */

-(void)setAudioChatProfile:(AudioChatCell *)cell dictChat:(NSDictionary *)dictChat{
    if ([self isNotNull:[dictChat objectForKey:@"profile_image"]] &&
        [[[[dictChat objectForKey:@"profile_image"] componentsSeparatedByString:@"/"] lastObject] componentsSeparatedByString:@"."].count>1) {
        
        [cell.lblProfile setHidden:TRUE];
        [cell.imgProfile setHidden:NO];
        NSString *thumbnailURL = [dictChat objectForKey:@"profile_image"];
        NSString *thumbnailName = [[thumbnailURL componentsSeparatedByString:@"/"] lastObject];
        NSArray *arrPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
        NSString *cachePath = [arrPaths objectAtIndex:0];
        NSString *localThumbnailPath = [cachePath stringByAppendingPathComponent:thumbnailName];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if(thumbnailURL && [fileManager fileExistsAtPath:localThumbnailPath]){
            cell.imgProfile.image = [UIImage imageWithData:[NSData dataWithContentsOfFile:localThumbnailPath]];
            [cell.indicator stopAnimating];
        }else if(thumbnailURL){
            AsynImageDownLoad *asynImageDownLoad = [[AsynImageDownLoad alloc] init];
            cell.asyncDownload = asynImageDownLoad;
            [asynImageDownLoad downLoadingAsynImage:cell.imgProfile imagePath:thumbnailURL backgroundQueue:NULL];
        }else{
            [cell.indicator stopAnimating];
        }
        
    }else{
        [cell.indicator stopAnimating];
        [cell.lblProfile setHidden:NO];
        NSString *firstInitial = @"";
        NSString *lastInitial = @"";
        NSString *companyInitial = @"";
        
        if (((NSString *)[dictChat objectForKey:@"first_name"]).length!=0) {
            firstInitial = [[((NSString *)[dictChat objectForKey:@"first_name"]) substringToIndex:1] uppercaseString];
        }
        
        if (((NSString *)[dictChat objectForKey:@"last_name"]).length!=0) {
            lastInitial = [[((NSString *)[dictChat objectForKey:@"last_name"]) substringToIndex:1] uppercaseString];
        }
        
        if (((NSString *)[dictChat objectForKey:@"company"]).length!=0) {
            companyInitial = [[((NSString *)[dictChat objectForKey:@"company"]) substringToIndex:1] uppercaseString];
        }
        
        NSLog(@"company name is %@",companyInitial);
        [cell.imgProfile setImage:[UIImage imageNamed:@"companyIcon"]];
        [cell.imgProfile setHidden:NO];
        [cell.lblProfile setHidden:YES];
        
        if (firstInitial.length !=0 || lastInitial.length != 0) {
            [cell.lblProfile setText:[[NSString stringWithFormat:@"%@%@",firstInitial,lastInitial] uppercaseString]];
            cell.imgProfile.backgroundColor = UIColorFromRedGreenBlue(216, 218, 227);
            [cell.imgProfile setHidden:YES];
            [cell.lblProfile setHidden:NO];
        }else if (companyInitial.length != 0){
            //[cell.lblProfile setText:[[NSString stringWithFormat:@"%@",companyInitial] uppercaseString]];
            [cell.imgProfile setImage:[UIImage imageNamed:@"companyIcon"]];
            cell.imgProfile.backgroundColor = UIColorFromRedGreenBlue(216, 218, 227);
            [cell.imgProfile setHidden:NO];
            [cell.lblProfile setHidden:YES];
        }else{
            [cell.imgProfile setImage:[UIImage imageNamed:@"profile_icon"]];
            [cell.imgProfile setHidden:NO];
            [cell.lblProfile setHidden:YES];
        }
    }
}

/**
 *called to set TextChat cell profile pic or initials
 *
 */

-(void)setTextChatProfile:(TextChatCell *)cell dictChat:(NSDictionary *)dictChat{
    if ([self isNotNull:[dictChat objectForKey:@"profile_image"]] &&
        [[[[dictChat objectForKey:@"profile_image"] componentsSeparatedByString:@"/"] lastObject] componentsSeparatedByString:@"."].count>1) {
        
        [cell.lblProfile setHidden:TRUE];
        [cell.imgProfile setHidden:NO];
        NSString *thumbnailURL = [dictChat objectForKey:@"profile_image"];
        NSString *thumbnailName = [[thumbnailURL componentsSeparatedByString:@"/"] lastObject];
        NSArray *arrPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
        NSString *cachePath = [arrPaths objectAtIndex:0];
        NSString *localThumbnailPath = [cachePath stringByAppendingPathComponent:thumbnailName];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if(thumbnailURL && [fileManager fileExistsAtPath:localThumbnailPath]){
            cell.imgProfile.image = [UIImage imageWithData:[NSData dataWithContentsOfFile:localThumbnailPath]];
            [cell.indicator stopAnimating];
        }else if(thumbnailURL){
            AsynImageDownLoad *asynImageDownLoad = [[AsynImageDownLoad alloc] init];
            cell.asyncDownload = asynImageDownLoad;
            [asynImageDownLoad downLoadingAsynImage:cell.imgProfile imagePath:thumbnailURL backgroundQueue:NULL];
        }else{
            [cell.indicator stopAnimating];
        }
        
    }else{
        [cell.indicator stopAnimating];
        [cell.lblProfile setHidden:NO];
        NSString *firstInitial = @"";
        NSString *lastInitial = @"";
        NSString *companyInitial = @"";
        
        if (((NSString *)[dictChat objectForKey:@"first_name"]).length!=0) {
            firstInitial = [[((NSString *)[dictChat objectForKey:@"first_name"]) substringToIndex:1] uppercaseString];
        }
        
        if (((NSString *)[dictChat objectForKey:@"last_name"]).length!=0) {
            lastInitial = [[((NSString *)[dictChat objectForKey:@"last_name"]) substringToIndex:1] uppercaseString];
        }
        
        if (((NSString *)[dictChat objectForKey:@"company"]).length!=0) {
            companyInitial = [[((NSString *)[dictChat objectForKey:@"company"]) substringToIndex:1] uppercaseString];
        }
        
        NSLog(@"company name is %@",companyInitial);
        [cell.imgProfile setImage:[UIImage imageNamed:@"companyIcon"]];
        [cell.imgProfile setHidden:NO];
        [cell.lblProfile setHidden:YES];
        
        if (firstInitial.length !=0 || lastInitial.length != 0) {
            [cell.lblProfile setText:[[NSString stringWithFormat:@"%@%@",firstInitial,lastInitial] uppercaseString]];
            cell.imgProfile.backgroundColor = UIColorFromRedGreenBlue(216, 218, 227);
            [cell.imgProfile setHidden:YES];
            [cell.lblProfile setHidden:NO];
        }else if (companyInitial.length != 0){
            //[cell.lblProfile setText:[[NSString stringWithFormat:@"%@",companyInitial] uppercaseString]];
            cell.imgProfile.backgroundColor = UIColorFromRedGreenBlue(216, 218, 227);
            [cell.imgProfile setImage:[UIImage imageNamed:@"companyIcon"]];
            [cell.imgProfile setHidden:NO];
            [cell.lblProfile setHidden:YES];
        }else{
            [cell.imgProfile setImage:[UIImage imageNamed:@"profile_icon"]];
            [cell.imgProfile setHidden:NO];
            [cell.lblProfile setHidden:YES];
        }
    }
}

/**
 *called to set Chat Media cell profile pic or initials
 *
 */
-(void)setChatMediaProfile:(ChatMediaCell *)cell dictChat:(NSDictionary *)dictChat{
    if ([[[[dictChat objectForKey:@"profile_image"] componentsSeparatedByString:@"/"] lastObject] componentsSeparatedByString:@"."].count>1) {
        
        [cell.lblProfile setHidden:TRUE];
        [cell.imgProfile setHidden:NO];
        
        NSString *thumbnailURL = [dictChat objectForKey:@"profile_image"];
        NSString *thumbnailName = [[thumbnailURL componentsSeparatedByString:@"/"] lastObject];
        NSArray *arrPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
        NSString *cachePath = [arrPaths objectAtIndex:0];
        NSString *localThumbnailPath = [cachePath stringByAppendingPathComponent:thumbnailName];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if(thumbnailURL && [fileManager fileExistsAtPath:localThumbnailPath]){
            cell.imgProfile.image = [UIImage imageWithData:[NSData dataWithContentsOfFile:localThumbnailPath]];
            [cell.indicator stopAnimating];
        }else if(thumbnailURL){
            AsynImageDownLoad *asynImageDownLoad = [[AsynImageDownLoad alloc] init];
            cell.asyncDownload = asynImageDownLoad;
            [asynImageDownLoad downLoadingAsynImage:cell.imgProfile imagePath:thumbnailURL backgroundQueue:NULL];
        }else{
            [cell.indicator stopAnimating];
        }
        
    }else{
        [cell.indicator stopAnimating];
        [cell.lblProfile setHidden:NO];
        NSString *firstInitial = @"";
        NSString *lastInitial = @"";
        NSString *companyInitial = @"";
        
        if (((NSString *)[dictChat objectForKey:@"first_name"]).length!=0) {
            firstInitial = [[(NSString *)[dictChat objectForKey:@"first_name"] substringToIndex:1] uppercaseString];
        }
        
        if (((NSString *)[dictChat objectForKey:@"last_name"]).length!=0) {
            lastInitial = [[(NSString *)[dictChat objectForKey:@"last_name"] substringToIndex:1] uppercaseString];
        }
        
        if (((NSString *)[dictChat objectForKey:@"company"]).length!=0) {
            companyInitial = [[(NSString *)[dictChat objectForKey:@"company"] substringToIndex:1] uppercaseString];
        }
        
        NSLog(@"company name is %@",companyInitial);
        [cell.imgProfile setImage:[UIImage imageNamed:@"companyIcon"]];
        [cell.imgProfile setHidden:NO];
        [cell.lblProfile setHidden:YES];
        
        if (firstInitial.length !=0 || lastInitial.length != 0) {
            [cell.lblProfile setText:[[NSString stringWithFormat:@"%@%@",firstInitial,lastInitial] uppercaseString]];
            cell.imgProfile.backgroundColor = UIColorFromRedGreenBlue(216, 218, 227);
            [cell.imgProfile setHidden:YES];
            [cell.lblProfile setHidden:NO];
        }else if (companyInitial.length != 0){
            //[cell.lblProfile setText:[[NSString stringWithFormat:@"%@",companyInitial] uppercaseString]];
            [cell.imgProfile setImage:[UIImage imageNamed:@"companyIcon"]];
            cell.imgProfile.backgroundColor = UIColorFromRedGreenBlue(216, 218, 227);
            [cell.imgProfile setHidden:NO];
            [cell.lblProfile setHidden:YES];
        }else{
            [cell.imgProfile setImage:[UIImage imageNamed:@"profile_icon"]];
            [cell.imgProfile setHidden:NO];
            [cell.lblProfile setHidden:YES];
        }
    }
}

#pragma mark--
#pragma mark-- UITableviewDelegate and DataSource
/**
  *
  *return height for table view cell
  */
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dictMsgDetail = [self.arrFortMsg objectAtIndex:indexPath.row];
    NSString *mediaType = [dictMsgDetail objectForKey:@"ftype"];
    if ([mediaType isEqualToString:@"image"]|| [mediaType isEqualToString:@"video"]){
        
        NSString *str = [CommonFuntions convertForgeterUnicodeToEmoji:[dictMsgDetail objectForKey:@"message"]];
        float height=[self getCellHeight:str];
        
//        float h = 322;
        float h = 312;

        
        float actualHeight = height+h;
        NSLog(@"text = %@",str);
        NSLog(@"actual height = %f",actualHeight);
        
        if(actualHeight<=330)
        {
            return 330.0f;
        }
        else
        {
            return ceil(actualHeight);
        }

//        return 340.0f; //340.0f
    }else if ([mediaType isEqualToString:@"location"]){
        return 84.0f;
    }else if ([mediaType isEqualToString:@"contact"]){
        return 82.0f;
    }else{
        
        NSString *str = [CommonFuntions convertForgeterUnicodeToEmoji:[dictMsgDetail objectForKey:@"message"]];

        float height=[self getCellHeight:str];
        
        //        float staticHeight = 46;
        
        float actualHeight = height+52;
        NSLog(@"text = %@",str);
        NSLog(@"actual height = %f",actualHeight);
        
        if(actualHeight<=70)
        {
            return 70.0f;
        }
        else
        {
            return ceil(actualHeight);
        }

//        return 70.0f;
    }
}

-(CGFloat)getCellHeight:(NSString *)strMsg{
    
    CGRect frame;
    CGSize size;
    
    
    CGSize constrainedSize = CGSizeMake(self.view.frame.size.width-88, 9999);
    
    
    frame = [strMsg
             boundingRectWithSize:constrainedSize
             options:NSStringDrawingUsesLineFragmentOrigin
             attributes:@{NSFontAttributeName:[UIFont fontWithName:@"Avenir Medium" size:13]}
             context:nil];
    
    size = frame.size;
    
    return size.height;
    
}

/**
 *
 *return number of rows in tableview
 */
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.arrFortMsg.count;
}

/**
 *
 *return cell view for specific row in specific section
 */
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dictMsgDetail = [self.arrFortMsg objectAtIndex:indexPath.row];
    NSString *mediaType = [dictMsgDetail objectForKey:@"ftype"];
    NSString *strTurl = [dictMsgDetail objectForKey:@"turl"];
    
    if ([mediaType isEqualToString:@"image"] || [mediaType isEqualToString:@"video"])
     {
         //Getting dequed media chat cell if existing
         ChatMediaCell *cell= (ChatMediaCell *)[tableView dequeueReusableCellWithIdentifier:@"ChatMediaCell"];
         
         //Creating one new chat cell , of media type
         if (cell==nil) {
             NSLog(@"creating new cell");
             cell = [[ChatMediaCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ChatMediaCell"];
             [cell.viewDownload setBackgroundColor:[UIColor clearColor]];
             [cell.btnDownload setBackgroundColor:[UIColor clearColor]];
         }
         
         //Making MediaView from Bottom 10 px up
         [cell.cnstMediaBottom setConstant:cell.cnstMediaBottom.constant+10];
         
         
         cell.btmMessageHeightConstraint.constant = 8.0f;
         
         //Showing Alternate Cell Background color
         int rowNum = [self getRowNumber:indexPath];
         NSLog(@"row num is %d",rowNum);
         if ((rowNum+1)%2==0 && arrFortMsg.count%2 == 0) {
             cell.backgroundColor = [UIColor whiteColor];
         }else if((rowNum+1)%2!=0 && arrFortMsg.count%2 != 0){
             cell.backgroundColor = [UIColor whiteColor];
         }else{
             cell.backgroundColor = UIColorFromRedGreenBlue(244, 243, 249);
         }
         
         
         //Showing Profile Image or Initials
         NSDictionary *userData = [[NSUserDefaults standardUserDefaults] valueForKey:@"UserProfileInfo"];
         NSDictionary *dictNames = [CommonFuntions getSeparateNamesWith:[userData objectForKey:@"name"]];
         
         NSDictionary *dictChatData = [NSDictionary dictionaryWithObjectsAndKeys:([userData objectForKey:@"profile_picture"]?[userData objectForKey:@"profile_picture"]:@""),@"profile_image",([dictNames objectForKey:@"first_name"]?[dictNames objectForKey:@"first_name"]:@""),@"first_name",([dictNames objectForKey:@"last_name"]?[dictNames objectForKey:@"last_name"]:@""),@"last_name",@"",@"company", nil];
         [self setChatMediaProfile:cell dictChat:dictChatData];
         
         
         NSDictionary *dictUserProfile = (NSDictionary *)[[NSUserDefaults standardUserDefaults] objectForKey:@"UserProfileInfo"];
         if([self isNotNull:dictUserProfile]){
             NSString *meName = [dictUserProfile objectForKey:@"name"];
             if([self isNotNull:meName])
                 cell.lblUsername.text = meName;
         }
         
         
         
         //Chat Message with Media
         if([self isNotNull:[dictMsgDetail objectForKey:@"message"]])
         {
//             NSString *strMessage = [dictMsgDetail objectForKey:@"message"];\\
             
             NSString *strMessage = [CommonFuntions convertForgeterUnicodeToEmoji:[dictMsgDetail objectForKey:@"message"]];

             if(strMessage.length!=0){
                 cell.lblChatMedia.text = strMessage;
                 [cell.topConstraintIcon setConstant:0.0f];
             }else{
                 cell.lblChatMedia.text =@"";
             }
         }else{
             cell.lblChatMedia.text =@"";
             [cell.topConstraintIcon setConstant:13.0f];
         }
         
         
         //Chat message date
         if([self isNotNull:[dictMsgDetail objectForKey:@"utc_time"]])
         {
             NSString *strDate = [dictMsgDetail objectForKey:@"utc_time"];
             NSString *strFormattedDate =  [self convertUTCtoLocal:strDate];
             if(strDate.length!=0)
             {
                 cell.lblDate.text = strFormattedDate;
             }
             
             float timeStampWidth = 0;
             if (IOS_8_OR_MAJOR) {
                 CGRect maxFrame = [strFormattedDate
                                    boundingRectWithSize:CGSizeMake(98,14)
                                    options:NSStringDrawingUsesLineFragmentOrigin
                                    attributes:@{NSFontAttributeName:[UIFont fontWithName:@"Avenir Medium" size:10],NSForegroundColorAttributeName:[UIColor colorWithRed:155/255.0f green:167/255.0f blue:175/255.0f alpha:1]}
                                    context:nil];
                 timeStampWidth = maxFrame.size.width;
             }else{
                 CGSize timeStampSize =[strFormattedDate sizeWithFont:[UIFont fontWithName:@"Avenir Medium" size:10] constrainedToSize:CGSizeMake(98,14) lineBreakMode:NSLineBreakByWordWrapping];
                 timeStampWidth = timeStampSize.width;
             }
             cell.cnstTimeStampWidth.constant = timeStampWidth+5;
         }
         
         
         [cell.btnDownload setTag:indexPath.row];
         [cell.btnDownload removeTarget:self action:@selector(callVideoDownload:) forControlEvents:UIControlEventTouchUpInside];
         [cell.btnDownload removeTarget:self action:@selector(showChatMediaOnClick:) forControlEvents:UIControlEventTouchUpInside];
         cell.imgChatMedia.hidden = NO;
         [cell.imgChatMedia setImage:nil];
         [cell.btnDownload setImage:nil forState:UIControlStateNormal];
         
         if ([self isNotNull:[dictMsgDetail objectForKey:@"turl"]]){
             //Media is uploaded by other one in group
             
             if([[dictMsgDetail objectForKey:@"ftype"] isEqualToString:@"image"])
             {
                 //Hiding video download icon
                 [cell.btnDownload setHidden:NO];
                 [cell.imgChatMedia setHidden:NO];
                 [cell.btnDownload setImage:nil forState:UIControlStateNormal];
                 //block is executed when media is of image type
                 if(strTurl.length!=0)
                 {
                     //need to check whether media is existing locally or not
                     
                     NSString *mediaURL = [dictMsgDetail objectForKey:@"turl"];
                     BOOL isFileCached = [CommonFuntions doesFileCachedWithFileURL:[dictMsgDetail objectForKey:@"turl"]];
                     
                     [cell.btnDownload addTarget:self action:@selector(showChatMediaOnClick:) forControlEvents:UIControlEventTouchUpInside];
                     
                     if(isFileCached){
                         NSLog(@"loading file locally");
                         cell.imgChatMedia.image = [UIImage imageWithData:[NSData dataWithContentsOfFile:[CommonFuntions localMediaPathForServerFile:mediaURL]]];
                         [cell.mediaIndicator stopAnimating];
                     }else if(mediaURL && mediaURL.length>0){
                         MediaQuickDownload *mediaDownloader = [[MediaQuickDownload alloc] init];
                         mediaDownloader.mediaType = Image;
                         mediaDownloader.imgMedia = cell.imgChatMedia;
                         cell.mediaQuickDonwloader = mediaDownloader;
                         cell.controller = self;
                         [mediaDownloader downloadForgeterMedia:[dictMsgDetail objectForKey:@"turl"]];
                         [cell.mediaIndicator startAnimating];
                     }else{
                         [cell.mediaIndicator stopAnimating];
                     }
                 }
             }else if ([[dictMsgDetail objectForKey:@"ftype"] isEqualToString:@"video"]){
                 //Block is executed when media is of video type
                 
                 //Showning video download icon
                 [cell.btnDownload setHidden:YES];
                 [cell.imgChatMedia setHidden:NO];
                 if([[dictMsgDetail objectForKey:@"ftype"] isEqualToString:@"video"])
                 {
                     
                     //need to check whether media is existing locally or not
                     NSString *thumbNailURL = [dictMsgDetail objectForKey:@"thumbnail"];
                     BOOL isThumbNailFileCached = NO;
                     if (thumbNailURL) {
                         isThumbNailFileCached = [CommonFuntions doesFileCachedWithFileURL:thumbNailURL];
                     }
                     NSLog(@"local thumbnail url is %@",[CommonFuntions localMediaPathForServerFile:thumbNailURL]);
                     
                     if(isThumbNailFileCached){
                         
                         
                         
                         NSString *videoLocalURL = [dictMsgDetail objectForKey:@"turl"];
                         BOOL isVideoCached = [CommonFuntions doesFileCachedWithFileURL:videoLocalURL];
                         NSLog(@"local video url is %@",[CommonFuntions localMediaPathForServerFile:videoLocalURL]);
                         if (isVideoCached) {
                             //Show play icon
                             NSURL *videoURL = [NSURL fileURLWithPath:[CommonFuntions localMediaPathForServerFile:videoLocalURL]];
                             [self generateThumbnailIconForVideoFileWith:videoURL WithSize:CGSizeMake(152,40) thumbnailContainer:cell.imgChatMedia];
                             [cell.btnDownload setImage:[UIImage imageNamed:@"playicon"] forState:UIControlStateNormal];
                             
                             [cell.btnDownload addTarget:self action:@selector(showChatMediaOnClick:) forControlEvents:UIControlEventTouchUpInside];
                             [cell.btnDownload setHidden:NO];
                             [cell.mediaIndicator stopAnimating];
                         }else{
                             //Show Video Download Icon
                             cell.imgChatMedia.image = [UIImage imageWithData:[NSData dataWithContentsOfFile:[CommonFuntions localMediaPathForServerFile:thumbNailURL]]];
                             [cell.btnDownload setImage:[UIImage imageNamed:@"downloadIcon"] forState:UIControlStateNormal];
                             [cell.btnDownload addTarget:self action:@selector(callVideoDownload:) forControlEvents:UIControlEventTouchUpInside];
                             [cell.btnDownload setHidden:NO];
                             [cell.mediaIndicator stopAnimating];
                         }
                     }else if(thumbNailURL && thumbNailURL.length>0){
                         NSLog(@"video url is %@",[dictMsgDetail objectForKey:@"thumbnail"]);
                         MediaQuickDownload *mediaDownloader = [[MediaQuickDownload alloc] init];
                         mediaDownloader.mediaType = Thumbnail;
                         mediaDownloader.imgMedia = cell.imgChatMedia;
                         cell.mediaQuickDonwloader = mediaDownloader;
                         cell.controller = self;
                         [mediaDownloader addObserver:cell forKeyPath:@"loadedFile" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:nil];
                         [mediaDownloader downloadForgeterMedia:[dictMsgDetail objectForKey:@"thumbnail"]];
                         cell.mediaURL = [dictMsgDetail objectForKey:@"turl"];
                         [cell.mediaIndicator startAnimating];
                     }else{
                         [cell.mediaIndicator stopAnimating];
                     }
                 }
             }
         }
         
         if([self forgeterDateMessage:[dictMsgDetail objectForKey:@"send_date"]]){
             cell.lblFortMsg.text = [self forgeterDateMessage:[dictMsgDetail objectForKey:@"send_date"]];
             [cell.lblFortMsg setHidden:NO];
         }
         
         return cell;
     }else if ([mediaType isEqualToString:@"location"]){
         LocationChatCell  *cell=[tableView dequeueReusableCellWithIdentifier:@"LocationChatCell"];
         
         if (cell==nil)
         {
             cell = [[LocationChatCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"LocationChatCell"];
             [cell.btnLocation addTarget:self action:@selector(showLocationInMap:) forControlEvents:UIControlEventTouchUpInside];
         }
         
         
         cell.btnLocation.tag = indexPath.row;
         
         
         //---------------SET Alternate Color for Cell---------//
         
         //Showing Alternate Cell Background color
         int rowNum = [self getRowNumber:indexPath];
         NSLog(@"row num is %d",rowNum);
         if ((rowNum+1)%2==0 && arrFortMsg.count%2 == 0) {
             cell.backgroundColor = [UIColor whiteColor];
         }else if((rowNum+1)%2!=0 && arrFortMsg.count%2 != 0){
             cell.backgroundColor = [UIColor whiteColor];
         }else{
             cell.backgroundColor = UIColorFromRedGreenBlue(244, 243, 249);
         }
         
         
         //Showing Profile Image or Initials
         NSDictionary *userData = [[NSUserDefaults standardUserDefaults] valueForKey:@"UserProfileInfo"];
         NSDictionary *dictNames = [CommonFuntions getSeparateNamesWith:[userData objectForKey:@"name"]];
         
         NSDictionary *dictChatData = [NSDictionary dictionaryWithObjectsAndKeys:([userData objectForKey:@"profile_picture"]?[userData objectForKey:@"profile_picture"]:@""),@"profile_image",([dictNames objectForKey:@"first_name"]?[dictNames objectForKey:@"first_name"]:@""),@"first_name",([dictNames objectForKey:@"last_name"]?[dictNames objectForKey:@"last_name"]:@""),@"last_name",@"",@"company", nil];
         [self setLocationChatProfile:cell dictChat:dictChatData];
         
         NSDictionary *dictUserProfile = (NSDictionary *)[[NSUserDefaults standardUserDefaults] objectForKey:@"UserProfileInfo"];
         if([self isNotNull:dictUserProfile])
         {
             NSString *meName = [dictUserProfile objectForKey:@"name"];
             if([self isNotNull:meName])
                 cell.lblUserName.text = meName;
         }
         
         
         //Chat message date, fixed to required width
         if([self isNotNull:[dictMsgDetail objectForKey:@"utc_time"]])
         {
             NSString *strDate = [dictMsgDetail objectForKey:@"utc_time"];
             NSString *strFormattedDate =  [self convertUTCtoLocal:strDate];
             if(strDate.length!=0)
             {
                 cell.lblDate.text = strFormattedDate;
             }
             
             float timeStampWidth = 0;
             if (IOS_8_OR_MAJOR) {
                 CGRect maxFrame = [strFormattedDate
                                    boundingRectWithSize:CGSizeMake(98,14)
                                    options:NSStringDrawingUsesLineFragmentOrigin
                                    attributes:@{NSFontAttributeName:[UIFont fontWithName:@"Avenir Medium" size:10],NSForegroundColorAttributeName:[UIColor colorWithRed:155/255.0f green:167/255.0f blue:175/255.0f alpha:1]}
                                    context:nil];
                 timeStampWidth = maxFrame.size.width;
             }else{
                 CGSize timeStampSize =[strFormattedDate sizeWithFont:[UIFont fontWithName:@"Avenir Medium" size:10] constrainedToSize:CGSizeMake(98,14) lineBreakMode:NSLineBreakByWordWrapping];
                 timeStampWidth = timeStampSize.width;
             }
             cell.cnstTimeStampWidth.constant = timeStampWidth+5;
         }
         
         
         //Message delivery status
         if([dictMsgDetail objectForKey:@"sent"] && [[dictMsgDetail objectForKey:@"sent"] intValue]==1 ){
             [cell.btnTik setImage:nil forState:UIControlStateNormal];
             [cell.btnTik setImage:[UIImage imageNamed:@"sentMsg"] forState:UIControlStateNormal];
         }else{
             [cell.btnTik setImage:nil forState:UIControlStateNormal];
             [cell.btnTik setImage:[UIImage imageNamed:@"msg_tick"] forState:UIControlStateNormal];
         }
         
         
         if([self isNotNull:[dictMsgDetail objectForKey:@"turl"]])
         {
             NSString *strMessage = [dictMsgDetail objectForKey:@"turl"];
             NSArray *arrLocation= [strMessage componentsSeparatedByString:@"#"];
             if(arrLocation.count>0)
             {
                 if([self isNotNull:[arrLocation objectAtIndex:2]])
                     cell.lblAddress.text = [arrLocation objectAtIndex:2];
             }
         }
         
         if([self forgeterDateMessage:[dictMsgDetail objectForKey:@"send_date"]]){
             cell.lblFortMsg.text = [self forgeterDateMessage:[dictMsgDetail objectForKey:@"send_date"]];
             [cell.lblFortMsg setHidden:NO];
         }
         
         return cell;
     }else if([mediaType isEqualToString:@"contact"]){
         ContactChatCell  *cell=[tableView dequeueReusableCellWithIdentifier:@"ContactChatCell"];
         
         if (cell==nil)
         {
             cell = [[ContactChatCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ContactChatCell"];
             [cell.btnContact addTarget:self action:@selector(showContactDetail:) forControlEvents:UIControlEventTouchUpInside];
         }
         cell.btnContact.tag = indexPath.row;
         
         
         
         //Message delivery status
         if([dictMsgDetail objectForKey:@"sent"] &&
            [[dictMsgDetail objectForKey:@"sent"] intValue] == 1){
             [cell.btnStatus setImage:nil forState:UIControlStateNormal];
             [cell.btnStatus setImage:[UIImage imageNamed:@"sentMsg"] forState:UIControlStateNormal];
         }else{
             [cell.btnStatus setImage:nil forState:UIControlStateNormal];
             [cell.btnStatus setImage:[UIImage imageNamed:@"msg_tick"] forState:UIControlStateNormal];
         }
         
         
         //Showing Alternate Cell Background color
         int rowNum = [self getRowNumber:indexPath];
         NSLog(@"row num is %d",rowNum);
         if ((rowNum+1)%2==0 && arrFortMsg.count%2 == 0) {
             cell.backgroundColor = [UIColor whiteColor];
         }else if((rowNum+1)%2!=0 && arrFortMsg.count%2 != 0){
             cell.backgroundColor = [UIColor whiteColor];
         }else{
             cell.backgroundColor = UIColorFromRedGreenBlue(244, 243, 249);
         }
         
         
         //Showing User Profile or Initials
         NSDictionary *userData = [[NSUserDefaults standardUserDefaults] valueForKey:@"UserProfileInfo"];
         NSDictionary *dictNames = [CommonFuntions getSeparateNamesWith:[userData objectForKey:@"name"]];
         
         NSDictionary *dictChatData = [NSDictionary dictionaryWithObjectsAndKeys:([userData objectForKey:@"profile_picture"]?[userData objectForKey:@"profile_picture"]:@""),@"profile_image",([dictNames objectForKey:@"first_name"]?[dictNames objectForKey:@"first_name"]:@""),@"first_name",([dictNames objectForKey:@"last_name"]?[dictNames objectForKey:@"last_name"]:@""),@"last_name",@"",@"company", nil];
         [self setContactChatProfile:cell dictChat:dictChatData];
         
         
         NSDictionary *dictUserProfile = (NSDictionary *)[[NSUserDefaults standardUserDefaults] objectForKey:@"UserProfileInfo"];
         if([self isNotNull:dictUserProfile])
         {
             NSString *meName = [dictUserProfile objectForKey:@"name"];
             if([self isNotNull:meName])
                 cell.lblUsername.text = meName;
         }
         
         
         //Chat message date, fixed to required width
         if([self isNotNull:[dictMsgDetail objectForKey:@"utc_time"]])
         {
             NSString *strDate = [dictMsgDetail objectForKey:@"utc_time"];
             NSString *strFormattedDate =  [self convertUTCtoLocal:strDate];
             if(strDate.length!=0)
             {
                 cell.lblDate.text = strFormattedDate;
             }
             
             float timeStampWidth = 0;
             if (IOS_8_OR_MAJOR) {
                 CGRect maxFrame = [strFormattedDate
                                    boundingRectWithSize:CGSizeMake(98,14)
                                    options:NSStringDrawingUsesLineFragmentOrigin
                                    attributes:@{NSFontAttributeName:[UIFont fontWithName:@"Avenir Medium" size:10],NSForegroundColorAttributeName:[UIColor colorWithRed:155/255.0f green:167/255.0f blue:175/255.0f alpha:1]}
                                    context:nil];
                 timeStampWidth = maxFrame.size.width;
             }else{
                 CGSize timeStampSize =[strFormattedDate sizeWithFont:[UIFont fontWithName:@"Avenir Medium" size:10] constrainedToSize:CGSizeMake(98,14) lineBreakMode:NSLineBreakByWordWrapping];
                 timeStampWidth = timeStampSize.width;
             }
             cell.cnstTimeStampWidth.constant = timeStampWidth+5;
         }
         
         
         if([self isNotNull:[dictMsgDetail objectForKey:@"turl"]])
         {
             Person *objPersons = [[Person alloc] init];
             NSString *strMessage = [dictMsgDetail objectForKey:@"turl"];
             NSArray *arrLocation= [strMessage componentsSeparatedByString:@"#"];
             if(arrLocation.count>0)
             {
                 for(int i=0; i<arrLocation.count; i++)
                 {
                     switch (i) {
                         case 0:
                             if([self isNotNull:[arrLocation objectAtIndex:0]])
                             {
                                 objPersons.address = [arrLocation objectAtIndex:0];
                             }
                             break;
                             
                         case 1:
                             if([self isNotNull:[arrLocation objectAtIndex:1]])
                             {
                                 objPersons.city = [arrLocation objectAtIndex:1];
                             }
                             break;
                         case 2:
                             if([self isNotNull:[arrLocation objectAtIndex:2]])
                             {
                                 objPersons.firstName = [arrLocation objectAtIndex:2];
                             }
                             break;
                         case 3:
                             if([self isNotNull:[arrLocation objectAtIndex:3]])
                             {
                                 objPersons.homeEmail = [arrLocation objectAtIndex:3];
                             }
                             break;
                         case 4:
                             if([self isNotNull:[arrLocation objectAtIndex:4]])
                             {
                                 objPersons.homeNumber = [arrLocation objectAtIndex:4];
                             }
                             break;
                         case 5:
                             if([self isNotNull:[arrLocation objectAtIndex:5]])
                             {
                                 objPersons.lastName = [arrLocation objectAtIndex:5];
                             }
                             break;
                         case 6:
                             if([self isNotNull:[arrLocation objectAtIndex:6]])
                             {
                                 objPersons.phoneNumber = [arrLocation objectAtIndex:6];
                             }
                             break;
                         case 7:
                             if([self isNotNull:[arrLocation objectAtIndex:7]])
                             {
                                 objPersons.workEmail = [arrLocation objectAtIndex:7];
                             }
                             
                             break;
                         case 8:
                             if([self isNotNull:[arrLocation objectAtIndex:8]])
                             {
                                 objPersons.zipCode = [arrLocation objectAtIndex:8];
                             }
                             break;
                     }
                 }
                 
             }
             
             if([self isNotNull:objPersons])
             {
                 NSString *firstInitial = objPersons.firstName;
                 NSString *lastInitial = objPersons.lastName;
                 NSString *fullName = @"";
                 if ([self isNotNull:firstInitial]) {
                     if(firstInitial.length!=0)
                         fullName = firstInitial;
                 }
                 
                 if ([self isNotNull:lastInitial]) {
                     if(lastInitial.length!=0)
                         fullName = [fullName stringByAppendingFormat:@" %@",lastInitial];
                 }
                 
                 cell.lblContactName.text = fullName;
                 if(fullName.length == 0)
                 {
                     if([self isNotNull:objPersons.phoneNumber])
                         [cell.lblContactName setText:objPersons.phoneNumber];
                     
                     if([self isNotNull:objPersons.homeNumber])
                         [cell.lblContactName setText:objPersons.homeNumber];
                 }
                 
                 
                 if ([self isNotNull:firstInitial]) {
                     if(firstInitial.length!=0)
                         firstInitial = [[firstInitial substringToIndex:1] uppercaseString];
                 }
                 
                 if ([self isNotNull:lastInitial]) {
                     if(lastInitial.length!=0)
                         lastInitial = [[lastInitial substringToIndex:1] uppercaseString];
                 }
                 
                 [cell.lblContact setText:[NSString stringWithFormat:@"%@%@",firstInitial,lastInitial]];
             }
             
         }
         
         if([self forgeterDateMessage:[dictMsgDetail objectForKey:@"send_date"]]){
             cell.lblFortMSg.text = [self forgeterDateMessage:[dictMsgDetail objectForKey:@"send_date"]];
             [cell.lblFortMSg setHidden:NO];
         }
         
         return cell;
     }else{
         
         TextChatCell *cell=[tableView dequeueReusableCellWithIdentifier:@"TextChatCell"];
         
         if (cell==nil) {
             cell = [[TextChatCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"TextChatCell"];
             cell.imgProfile.layer.cornerRadius=22.0f;
             cell.imgProfile.layer.masksToBounds=YES;
             cell.imgProfile.backgroundColor=[UIColor colorWithRed:216.0f/255.0f green:218.0f/255.0f blue:227.0f/255.0f alpha:1.0f];
             cell.selectionStyle = UITableViewCellSelectionStyleNone;
             
         }
         //---------------SET Alternate Color for Cell---------//
         
         //Showing Alternate Cell Background color
         int rowNum = [self getRowNumber:indexPath];
         NSLog(@"row num is %d",rowNum);
         if ((rowNum+1)%2==0 && arrFortMsg.count%2 == 0) {
             cell.backgroundColor = [UIColor whiteColor];
         }else if((rowNum+1)%2!=0 && arrFortMsg.count%2 != 0){
             cell.backgroundColor = [UIColor whiteColor];
         }else{
             cell.backgroundColor = UIColorFromRedGreenBlue(244, 243, 249);
         }
         
         
         //Showing User Profile Detail
         NSDictionary *userData = [[NSUserDefaults standardUserDefaults] valueForKey:@"UserProfileInfo"];
         NSDictionary *dictNames = [CommonFuntions getSeparateNamesWith:[userData objectForKey:@"name"]];
         
         NSDictionary *dictChatData = [NSDictionary dictionaryWithObjectsAndKeys:([userData objectForKey:@"profile_picture"]?[userData objectForKey:@"profile_picture"]:@""),@"profile_image",([dictNames objectForKey:@"first_name"]?[dictNames objectForKey:@"first_name"]:@""),@"first_name",([dictNames objectForKey:@"last_name"]?[dictNames objectForKey:@"last_name"]:@""),@"last_name",@"",@"company", nil];
         [self setTextChatProfile:cell dictChat:dictChatData];
         
         
         NSDictionary *dictUserProfile = (NSDictionary *)[[NSUserDefaults standardUserDefaults] objectForKey:@"UserProfileInfo"];
         if([self isNotNull:dictUserProfile])
         {
             NSString *meName = [dictUserProfile objectForKey:@"name"];
             if([self isNotNull:meName])
                 cell.lblName.text = meName;
         }
         
         
         //Putting Message on cell
         if([self isNotNull:[dictMsgDetail objectForKey:@"message"]]){
             NSString *msgStr = [dictMsgDetail objectForKey:@"message"];
//             cell.lblMsg.text=msgStr;//[CommonFuntions convertUnicodeToEmoji:msgStr];
             
             cell.lblMsg.text = [CommonFuntions convertForgeterUnicodeToEmoji:msgStr];
         }
         
         
         //Chat message date to hold it in required width
         if([self isNotNull:[dictMsgDetail objectForKey:@"utc_time"]])
         {
             NSString *strDate = [dictMsgDetail objectForKey:@"utc_time"];
             NSString *strFormattedDate =  [self convertUTCtoLocal:strDate];
             if(strDate.length!=0)
             {
                 cell.lblDate.text = strFormattedDate;
             }
             
             float timeStampWidth = 0;
             if (IOS_8_OR_MAJOR) {
                 CGRect maxFrame = [strFormattedDate
                                    boundingRectWithSize:CGSizeMake(98,14)
                                    options:NSStringDrawingUsesLineFragmentOrigin
                                    attributes:@{NSFontAttributeName:[UIFont fontWithName:@"Avenir Medium" size:10],NSForegroundColorAttributeName:[UIColor colorWithRed:155/255.0f green:167/255.0f blue:175/255.0f alpha:1]}
                                    context:nil];
                 timeStampWidth = maxFrame.size.width;
             }else{
                 CGSize timeStampSize =[strFormattedDate sizeWithFont:[UIFont fontWithName:@"Avenir Medium" size:10] constrainedToSize:CGSizeMake(98,14) lineBreakMode:NSLineBreakByWordWrapping];
                 timeStampWidth = timeStampSize.width;
             }
             cell.cnstTimeStampWidth.constant = timeStampWidth+5;
         }
         
         //Delivery message status
         if([dictMsgDetail objectForKey:@"sent"]
            && [[dictMsgDetail objectForKey:@"sent"] intValue]==1){
             [cell.btnStatus setImage:nil forState:UIControlStateNormal];
             [cell.btnStatus setImage:[UIImage imageNamed:@"sentMsg"] forState:UIControlStateNormal];
         }else{
             [cell.btnStatus setImage:nil forState:UIControlStateNormal];
             [cell.btnStatus setImage:[UIImage imageNamed:@"msg_tick"] forState:UIControlStateNormal];
         }
         
         if([self forgeterDateMessage:[dictMsgDetail objectForKey:@"send_date"]]){
             cell.lblFortMsg.text = [self forgeterDateMessage:[dictMsgDetail objectForKey:@"send_date"]];
             [cell.lblFortMsg setHidden:NO];
         }
         
         
         return cell;
     }
    return nil;
}
#pragma mark GetForgeterMsgList Delegates
-(void)getForgeterMsgListfailed
{
    [CommonFuntions removeActivityIndicator];
      NSLog(@"forgeter message list fialed ");
}
-(void)getForgeterMsgListSuccessfully:(NSDictionary *)dictList
{
    [CommonFuntions removeActivityIndicator];
    NSLog(@"forgeter message list is %@ and user dict is %@",dictList,dictUserDetail);
    NSArray *arrMsgList = [dictList objectForKey:@"forgeterList"];
    self.arrFortMsg = [[NSMutableArray alloc] initWithArray:arrMsgList];
    [self.tblForgeter setHidden:false];
    [self.tblForgeter reloadData];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark--
#pragma mark-- Document Directory operation
- (NSString *)pathToUserPhotoFolder {
   
    NSString *temDirUrl = [NSTemporaryDirectory() stringByAppendingPathComponent:[dictUserDetail objectForKey:@"ejabber_username"]];
    BOOL isDir1 = NO;
    NSFileManager *fileManager1 = [[NSFileManager alloc] init];
    if (![fileManager1 fileExistsAtPath:temDirUrl
                            isDirectory:&isDir1] && isDir1 == NO) {
        [fileManager1 createDirectoryAtPath:temDirUrl
                withIntermediateDirectories:NO
                                 attributes:nil
                                      error:nil];
    }
    
    temDirUrl = [temDirUrl stringByAppendingPathComponent:@"ChatMedia"];
    // Create the folder if necessary
    BOOL isDir = NO;
    NSFileManager *fileManager = [[NSFileManager alloc] init];
    if (![fileManager fileExistsAtPath:temDirUrl
                           isDirectory:&isDir] && isDir == NO) {
        [fileManager createDirectoryAtPath:temDirUrl
               withIntermediateDirectories:NO
                                attributes:nil
                                     error:nil];
    }
    return temDirUrl;
}
-(BOOL)fileExistAtPath:(NSString *)imgName andType:(NSString *)type
{
    NSString *documentsPath = [self pathToUserPhotoFolder];
    NSString *filePath = [documentsPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@.png",type,imgName]];
    NSLog(@"DBPath == %@", filePath);
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:filePath] == YES)
        return YES;
    else
        return NO;
}

-(UIImage *)retriveImageWithName:(NSString *)imgName withType:(NSString *)type
{
    NSString *documentsPath = [self pathToUserPhotoFolder];
    NSString *filePath = [documentsPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@.png",type,imgName]];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    UIImage* image;
    if ([fileManager fileExistsAtPath:filePath] == YES)
    {
        image = [UIImage imageWithContentsOfFile:filePath];
    }
    else
        image = nil;
    
    return image;
}

-(BOOL)videoExistAtPath:(NSString *)videoName andType:(NSString *)type
{
    NSString *documentsPath = [self pathToUserPhotoFolder];
    NSString *filePath = [documentsPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@",type,videoName]];
    NSLog(@"DBPath == %@", filePath);
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:filePath] == YES)
        return YES;
    else
        return NO;
}

-(BOOL)fileVThumbExistAtPath:(NSString *)imgName
{
    NSString *documentsPath = [self pathToVThumbFolder];
    NSString *filePath = [documentsPath stringByAppendingPathComponent:imgName];
    NSLog(@"DBPath == %@", filePath);
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:filePath] == YES)
        return YES;
    else
        return NO;
}

-(UIImage *)retrivevThumbImageWithName:(NSString *)imgName
{
    NSString *documentsPath = [self pathToVThumbFolder];
    NSString *filePath = [documentsPath stringByAppendingPathComponent:imgName];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    UIImage* image;
    if ([fileManager fileExistsAtPath:filePath] == YES)
    {
        image = [UIImage imageWithContentsOfFile:filePath];
    }
    else
        image = nil;
    
    return image;
}

- (NSString *)pathToVThumbFolder
{
    NSString *temDirUrl = [[self documentPathForVThumbFolder] stringByAppendingPathComponent:@"/vthumb"];
    // Create the folder if necessary
    BOOL isDir = NO;
    NSFileManager *fileManager = [[NSFileManager alloc] init];
    if (![fileManager fileExistsAtPath:temDirUrl
                           isDirectory:&isDir] && isDir == NO) {
        [fileManager createDirectoryAtPath:temDirUrl
               withIntermediateDirectories:NO
                                attributes:nil
                                     error:nil];
    }
    return temDirUrl;
}
- (NSString *)documentPathForVThumbFolder
{
    NSString *temDirUrl = [NSTemporaryDirectory() stringByAppendingPathComponent:[dictUserDetail objectForKey:@"ejabber_username"]];
    BOOL isDir1 = NO;
    NSFileManager *fileManager1 = [[NSFileManager alloc] init];
    if (![fileManager1 fileExistsAtPath:temDirUrl
                            isDirectory:&isDir1] && isDir1 == NO) {
        [fileManager1 createDirectoryAtPath:temDirUrl
                withIntermediateDirectories:NO
                                 attributes:nil
                                      error:nil];
    }
    return temDirUrl;
}
#pragma mark forgeter date message
-(NSString *)forgeterDateMessage:(NSString *)msg
{//[dictMsgDetail objectForKey:@"send_date"]
    NSDateFormatter *dateFormeter = [[NSDateFormatter alloc] init];
    [dateFormeter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *forgeterMsg;
    if([dateFormeter dateFromString:msg])
    {
       forgeterMsg = [FORGETTER_MESSAGE stringByAppendingString:[CommonFuntions forgeterDateWithPrefix:[dateFormeter dateFromString:msg]]];
    }
    NSLog(@"forgeter msg is %@",forgeterMsg);
    return forgeterMsg;
}


@end
