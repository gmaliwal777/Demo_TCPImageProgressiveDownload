//
//  MediaQuickDownload.h
//  Forgeter
//
//  Created by Ghanshyam on 6/2/15.
//  Copyright (c) 2015 Ravi Taylor. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ImageQuickRender.h"
#import "MacroDefined.h"

@protocol MediaQuickDownloaderDelegate <NSObject>
-(void)mediaDownloadedSuccessfully;
-(void)mediaDownloadFailure;
@end

@interface MediaQuickDownload : NSObject<ImageRenderDelegate>{
    NSString        *localMediaURL;
    
    NSString        *loadedFile;
}

@property (nonatomic,weak)      UIImageView                 *imgMedia;
@property (nonatomic,strong)    ImageQuickRender            *mediaQuickRenderer;
@property (nonatomic,strong)    NSMutableData               *mediaData;
@property (nonatomic,assign)    MediaType                   mediaType;

@property (nonatomic,weak)      id<MediaQuickDownloaderDelegate>    delegate;

-(void)downloadForgeterMedia:(NSString *)remoteURL;
-(void)stopDownloading;

@end
